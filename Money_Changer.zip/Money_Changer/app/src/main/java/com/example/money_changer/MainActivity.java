package com.example.money_changer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
public TextView Amount,rm100quantity,rm50quantity,rm20quantity,rm10quantity,rm5quantity,
                rm1quantity,sen50quantity,sen20quantity,sen10quantity,sen5quantity,sen1quantity;
public Button AC,Back,Enter,zero,one,two,three,four,five,six,seven,eight,nine;
public static final String SHARE_PREF="shared";
public static final String TEXT= "text", TEXT1="text1", TEXT2="text2",TEXT3="text3",TEXT4="text4",TEXT5="text5",TEXT6="text6",TEXT7="text7",
                           TEXT8="text8",TEXT9="text9",TEXT10="text10",TEXT0="text0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle(Html.fromHtml
                ("<font color=\"black\">" + getString(R.string.app_name)+ "</font>"));// Title color

        //Display the number
        Amount = findViewById(R.id.amount);
        rm100quantity = findViewById(R.id.rm100quantity);
        rm50quantity = findViewById(R.id.rm50quantity);
        rm20quantity = findViewById(R.id.rm20quantity);
        rm10quantity = findViewById(R.id.rm10quantity);
        rm5quantity = findViewById(R.id.rm5quantity);
        rm1quantity = findViewById(R.id.rm1quantity);
        sen50quantity = findViewById(R.id.sen50quantity);
        sen20quantity = findViewById(R.id.sen20quantity);
        sen10quantity = findViewById(R.id.sen10quantity);
        sen5quantity = findViewById(R.id.sen5quantity);
        sen1quantity = findViewById(R.id.sen1quantity);

        //Button
        AC = findViewById(R.id.btnac);
        Back = findViewById(R.id.btnback);
        Enter = findViewById(R.id.btnenter);
        zero = findViewById(R.id.btn0);
        one = findViewById(R.id.btn1);
        two = findViewById(R.id.btn2);
        three = findViewById(R.id.btn3);
        four = findViewById(R.id.btn4);
        five = findViewById(R.id.btn5);
        six = findViewById(R.id.btn6);
        seven = findViewById(R.id.btn7);
        eight = findViewById(R.id.btn8);
        nine = findViewById(R.id.btn9);

        //click the button
        one.setOnClickListener(this);
        two.setOnClickListener(this);
        three.setOnClickListener(this);
        four.setOnClickListener(this);
        five.setOnClickListener(this);
        six.setOnClickListener(this);
        seven.setOnClickListener(this);
        eight.setOnClickListener(this);
        nine.setOnClickListener(this);
        zero.setOnClickListener(this);
        AC.setOnClickListener(this);
        Back.setOnClickListener(this);
        Enter.setOnClickListener(this);

        update();

    }

    private void update() {
        SharedPreferences sharedPreferences = getSharedPreferences(SHARE_PREF,MODE_PRIVATE);
        String text = sharedPreferences.getString(TEXT, "");
        String text1 = sharedPreferences.getString(TEXT1, "");
        String text2 = sharedPreferences.getString(TEXT2, "");
        String text3 = sharedPreferences.getString(TEXT3,"");
        String text4 = sharedPreferences.getString(TEXT4,"");
        String text5 = sharedPreferences.getString(TEXT5,"");
        String text6 = sharedPreferences.getString(TEXT6,"");
        String text7 = sharedPreferences.getString(TEXT7,"");
        String text8 = sharedPreferences.getString(TEXT8,"");
        String text9 = sharedPreferences.getString(TEXT9,"");
        String text10= sharedPreferences.getString(TEXT10,"");
        String text0 = sharedPreferences.getString(TEXT0,"");
        Amount.setText(text);
        rm100quantity.setText(text1);
        rm50quantity.setText(text2);
        rm20quantity.setText(text3);
        rm10quantity.setText(text4);
        rm5quantity.setText(text5);
        rm1quantity.setText(text6);
        sen50quantity.setText(text7);
        sen20quantity.setText(text8);
        sen10quantity.setText(text9);
        sen5quantity.setText(text10);
        sen1quantity.setText(text0);
    }




    @Override
        public void onClick (View v){
            switch (v.getId()) {

                case R.id.btn0:
                    changemoney("0");
                    break;
                case R.id.btn1:
                    changemoney("1");
                    break;
                case R.id.btn2:
                    changemoney("2");
                    break;
                case R.id.btn3:
                    changemoney("3");
                    break;
                case R.id.btn4:
                    changemoney("4");
                    break;
                case R.id.btn5:
                    changemoney("5");
                    break;
                case R.id.btn6:
                    changemoney("6");
                    break;
                case R.id.btn7:
                    changemoney("7");
                    break;
                case R.id.btn8:
                    changemoney("8");
                    break;
                case R.id.btn9:
                    changemoney("9");
                    break;
                case R.id.btnac:
                    ClearFunction(v);
                    ChangeQuantity(v);
                    break;
                case R.id.btnback:
                    BackFunction(v);
                    ChangeQuantity(v);
                    break;
                case R.id.btnenter:
                    ChangeQuantity(v);
                    break;

            }
            SharedPreferences sharedPreferences = getSharedPreferences(SHARE_PREF,MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString(TEXT,Amount.getText().toString());
            editor.putString(TEXT1,rm100quantity.getText().toString());
            editor.putString(TEXT2,rm50quantity.getText().toString());
            editor.putString(TEXT3,rm20quantity.getText().toString());
            editor.putString(TEXT4,rm10quantity.getText().toString());
            editor.putString(TEXT5,rm5quantity.getText().toString());
            editor.putString(TEXT6,rm1quantity.getText().toString());
            editor.putString(TEXT7,sen50quantity.getText().toString());
            editor.putString(TEXT8,sen20quantity.getText().toString());
            editor.putString(TEXT9,sen10quantity.getText().toString());
            editor.putString(TEXT10,sen5quantity.getText().toString());
            editor.putString(TEXT0,sen1quantity.getText().toString());
            editor.apply();

        }


        private void changemoney (String digit){

            String newamount = Amount.getText().toString().replace(".", "");
            newamount += digit;

            if (newamount.startsWith("0")) {
                newamount = newamount.substring(1);
            }

            Amount.setText(changeFunction(newamount));


        }
        public void ClearFunction (View view){
            Amount.setText("0.00");
            rm100quantity.setText("0");
            rm50quantity.setText("0");
            rm20quantity.setText("0");
            rm10quantity.setText("0");
            rm5quantity.setText("0");
            rm1quantity.setText("0");
            sen50quantity.setText("0");
            sen20quantity.setText("0");
            sen10quantity.setText("0");
            sen5quantity.setText("0");
            sen1quantity.setText("0");

        }
        public void BackFunction (View view){
            String value = Amount.getText().toString().replace(".", "");
            value = value.substring(0, value.length() - 1);
            Amount.setText(changeFunction(value));


        }
        private String changeFunction (String Amount){

            if(Amount.length()>9){
                return "---------";
            }else if(Amount.length() > 2) {
                return Amount.substring(0, Amount.length() - 2) + "." + Amount.substring(Amount.length() - 2);
            } else if (Amount.length() == 1) {
                return "0.0" + Amount;
            } else if (Amount.length() == 2) {
                return "0." + Amount;
            } else
                return "0.00";
        }

    public void ChangeQuantity (View view){
            int RM100 = 0, RM50 = 0, RM20 = 0, RM10 = 0, RM5 = 0, RM1 = 0,
                    sen50 = 0, sen20 = 0, sen10 = 0, sen5 = 0, sen1 = 0;



            String totalAmount = Amount.getText().toString().replace(".", "");

            int RM = Integer.valueOf(totalAmount.substring(0, totalAmount.length() - 2));
            int Sen = Integer.valueOf(totalAmount.substring(totalAmount.length() - 2));

            while (RM >= 0) {
                if (RM - 100 >= 0) {
                    RM -= 100;
                    RM100++;
                } else if (RM - 50 >= 0) {
                    RM -= 50;
                    RM50++;
                } else if (RM - 20 >= 0) {
                    RM -= 20;
                    RM20++;
                } else if (RM - 10 >= 0) {
                    RM -= 10;
                    RM10++;
                } else if (RM - 5 >= 0) {
                    RM -= 5;
                    RM5++;
                } else if (RM - 1 >= 0) {
                    RM -= 1;
                    RM1++;
                } else
                    break;
            }

            while (Sen >= 0) {
                if (Sen - 50 >= 0) {
                    Sen -= 50;
                    sen50++;
                } else if (Sen - 20 >= 0) {
                    Sen -= 20;
                    sen20++;
                } else if (Sen - 10 >= 0) {
                    Sen -= 10;
                    sen10++;
                } else if (Sen - 5 >= 0) {
                    Sen -= 5;
                    sen5++;
                } else if (Sen - 1 >= 0) {
                    Sen -= 1;
                    sen1++;
                } else
                    break;
            }

            rm100quantity.setText(String.valueOf(RM100));
            rm50quantity.setText(String.valueOf(RM50));
            rm20quantity.setText(String.valueOf(RM20));
            rm10quantity.setText(String.valueOf(RM10));
            rm5quantity.setText(String.valueOf(RM5));
            rm1quantity.setText(String.valueOf(RM1));
            sen50quantity.setText(String.valueOf(sen50));
            sen20quantity.setText(String.valueOf(sen20));
            sen10quantity.setText(String.valueOf(sen10));
            sen5quantity.setText(String.valueOf(sen5));
            sen1quantity.setText(String.valueOf(sen1));


        }
        

}
